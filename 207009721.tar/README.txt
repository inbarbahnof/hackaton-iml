USERS.txt - the user names
project.pdf - the overall flow of the project

in tas1 folder:
predictions folder:
passengers_up_predictions.csv - predictions for the subtask1
trip_duration_predictions.csv - predictions for the subtask2

answers folder:
conclusions_and_suggestions.pdf - answer for subtask3

code folder:
requirements.txt - the packages we used for the code
main_subtask1.py - the main for subtask1
main_subtask2.py - the main for subtask2

hackathon_code folder:
jupyter notebooks we used to check the preprocessing during the hackathon